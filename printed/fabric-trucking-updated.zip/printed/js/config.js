// Auto-generated config for printed page
window.PrintedConfig = {
  SUPABASE_URL: "https://umrczwoxjhxwvrezocrm.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVtcmN6d294amh4d3ZyZXpvY3JtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM5ODA0MTUsImV4cCI6MjA3OTU1NjQxNX0.88PDM2h93rhGhOxVRDa5q3rismemqJJEpmBdwWmfgVQ",
  TABLE_NAME: "printed_mariages",
  STORAGE_BUCKET: "images",
  STORAGE_PREFIX: "printed"
};
