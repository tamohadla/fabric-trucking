
(() => {
  'use strict';

  /******************** Config + Supabase ********************/
  const CFG = window.PrintedConfig;
  if (!CFG) {
    alert("Missing PrintedConfig.");
    return;
  }
  if (!window.supabase) {
    alert("Supabase library failed to load.");
    return;
  }
  const supabaseClient = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY);

  /******************** Helpers ********************/
  const ARABIC_DIGITS = { '٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9',
                          '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9' };

  function arabicToEnglishDigits(str) {
    if (str === null || str === undefined) return "";
    return String(str).split('').map(ch => ARABIC_DIGITS[ch] ?? ch).join('');
  }

  function onlyDigits(str) {
    return arabicToEnglishDigits(str).replace(/[^\d]/g, '');
  }

  function sanitizeDecimal(str) {
    if (str === null || str === undefined) return null;
    let s = arabicToEnglishDigits(String(str)).trim();
    if (!s) return null;
    // allow comma decimal
    s = s.replace(/,/g, '.');
    // remove everything except digits and dot
    s = s.replace(/[^0-9.]/g, '');
    if (!s) return null;
    const num = Number(s);
    return Number.isFinite(num) ? num : null;
  }

  function todayISO() {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function buildImageKey(designCode, mariageNumber) {
    const d = arabicToEnglishDigits(designCode || "").trim();
    const m = onlyDigits(mariageNumber || "");
    return `${d}|${m}`;
  }

  function buildImagePath(designCode, mariageNumber) {
    const d = arabicToEnglishDigits(designCode || "").trim();
    const m = onlyDigits(mariageNumber || "");
    // readable + deterministic
    return `${CFG.STORAGE_PREFIX}/${d}/${d}_m${m}.jpg`;
  }

  function extractStoragePathFromPublicUrl(publicUrl) {
    // expects .../storage/v1/object/public/<bucket>/<path>
    try {
      if (!publicUrl) return null;
      const marker = `/storage/v1/object/public/${CFG.STORAGE_BUCKET}/`;
      const idx = publicUrl.indexOf(marker);
      if (idx === -1) return null;
      return publicUrl.substring(idx + marker.length);
    } catch {
      return null;
    }
  }

  async function getPublicUrl(path) {
    const { data } = supabaseClient.storage.from(CFG.STORAGE_BUCKET).getPublicUrl(path);
    return data?.publicUrl || null;
  }

  async function storageExists(path) {
    // list by folder + search
    const parts = path.split('/');
    const fileName = parts.pop();
    const folder = parts.join('/');
    const { data, error } = await supabaseClient.storage.from(CFG.STORAGE_BUCKET).list(folder, { search: fileName, limit: 20 });
    if (error) return false;
    return Array.isArray(data) && data.some(it => it.name === fileName);
  }

  async function resizeToJpegFile(file, maxSize = 900, quality = 0.9) {
    // returns a new File (jpeg)
    const blob = await new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        canvas.toBlob((b) => {
          if (!b) reject(new Error("toBlob failed"));
          else resolve(b);
        }, 'image/jpeg', quality);
      };
      img.onerror = () => reject(new Error("image load failed"));
      img.src = URL.createObjectURL(file);
    });
    return new File([blob], "image.jpg", { type: "image/jpeg" });
  }

  async function uploadImageToPath(file, path, { upsert = false } = {}) {
    if (!file) return null;
    let jpegFile = file;
    try {
      jpegFile = await resizeToJpegFile(file, 1000, 0.9);
    } catch (e) {
      console.warn("Resize/convert failed, uploading original file:", e);
    }
    const { error } = await supabaseClient.storage
      .from(CFG.STORAGE_BUCKET)
      .upload(path, jpegFile, { upsert });

    if (error) throw error;
    return await getPublicUrl(path);
  }

  async function deleteStoragePath(path) {
    if (!path) return;
    const { error } = await supabaseClient.storage.from(CFG.STORAGE_BUCKET).remove([path]);
    if (error) throw error;
  }

  async function copyStoragePath(srcPath, dstPath) {
    // No server-side copy; download + upload
    const { data, error } = await supabaseClient.storage.from(CFG.STORAGE_BUCKET).download(srcPath);
    if (error) throw error;
    const blob = data;
    const file = new File([blob], "image.jpg", { type: blob.type || "image/jpeg" });
    // upsert false; if exists, skip
    const exists = await storageExists(dstPath);
    if (!exists) {
      const { error: upErr } = await supabaseClient.storage.from(CFG.STORAGE_BUCKET).upload(dstPath, file, { upsert: false });
      if (upErr) throw upErr;
    }
    return await getPublicUrl(dstPath);
  }

  async function moveStoragePath(srcPath, dstPath) {
    if (srcPath === dstPath) return await getPublicUrl(dstPath);
    await copyStoragePath(srcPath, dstPath);
    // delete old
    try { await deleteStoragePath(srcPath); } catch (e) { console.warn("Failed deleting old path:", e); }
    return await getPublicUrl(dstPath);
  }

  /******************** DOM Refs ********************/
  const groupsContainer = document.getElementById("groupsContainer");
  const addGroupBtn = document.getElementById("addGroupBtn");
  const saveAllBtn = document.getElementById("saveAllBtn");

  const designCodeInput = document.getElementById("designCode");
  const screensCountInput = document.getElementById("screensCount");

  const searchInput = document.getElementById("searchInput");
  const statusFilter = document.getElementById("statusFilter");
  const sortField = document.getElementById("sortField");
  const printedTableBody = document.getElementById("printedTableBody");
  const totalsInfo = document.getElementById("totalsInfo");
  const tableMessage = document.getElementById("tableMessage");

  // Edit modal
  const editModalBackdrop = document.getElementById("editModalBackdrop");
  const editModalClose = document.getElementById("editModalClose");
  const editSaveBtn = document.getElementById("editSaveBtn");
  const editMessage = document.getElementById("editMessage");
  const editUpdateImageBtn = document.getElementById("editUpdateImageBtn");
  const editImageFile = document.getElementById("edit_image_file");
  const editImagePreview = document.getElementById("edit_image_preview");

  // Duplicate modal
  const dupModalBackdrop = document.getElementById("dupModalBackdrop");
  const dupModalClose = document.getElementById("dupModalClose");
  const dupSaveBtn = document.getElementById("dupSaveBtn");
  const dupMessage = document.getElementById("dupMessage");
  const dupImagePreview = document.getElementById("dup_image_preview");

  // Image zoom modal
  const imageModal = document.getElementById("imageModal");
  const imageModalImg = document.getElementById("imageModalImg");

  /******************** State ********************/
  let printedData = [];
  let currentEditRow = null;
  let currentDupRow = null;

  /******************** Groups UI ********************/
  function setupDigitNormalization() {
    document.querySelectorAll(".normalize-digits").forEach(inp => {
      inp.addEventListener("input", () => {
        const val = inp.value;
        const converted = arabicToEnglishDigits(val);
        if (converted !== val) inp.value = converted;
      }, { passive: true });
    });
  }

  function makeGroup(index) {
    const group = document.createElement("div");
    group.className = "group";

    group.innerHTML = `
      <div class="row">
        <div class="col">
          <label>رقم المرياج:</label>
          <input class="mariage normalize-digits" type="text" inputmode="numeric" placeholder="مثال: 3" />
        </div>
        <div class="col">
          <label>نوع الطباعة:</label>
          <select class="printtype">
            <option value="بجمنت">بجمنت</option>
            <option value="راكتف">راكتف</option>
            <option value="دسبسرس">دسبسرس</option>
            <option value="سابلميشن">سابلميشن</option>
          </select>
        </div>
        <div class="col">
          <label>تحضير الأرضية:</label>
          <select class="groundprep">
            <option value="أوفوايت">أوفوايت</option>
            <option value="أبيض">أبيض</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>الخامة:</label>
          <input class="quality quality-input" type="text" list="qualityList" />
        </div>
        <div class="col">
          <label>الكمية (كغ):</label>
          <input class="qty normalize-digits" type="text" inputmode="decimal" placeholder="مثال: 350" />
        </div>
        <div class="col">
          <label>تاريخ الطلب:</label>
          <input class="date" type="date" />
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>الحالة:</label>
          <select class="status">
            <option value="لم يتم التشكيل">لم يتم التشكيل</option>
            <option value="تم التشكيل">تم التشكيل</option>
            <option value="تم الاستلام">تم الاستلام</option>
          </select>
        </div>
        <div class="col">
          <label>ملاحظات:</label>
          <input class="notes" type="text" placeholder="اختياري" />
        </div>
      </div>

      <div class="row">
        <div class="col">
          <label>صورة المرياج (اختياري):</label>
          <input class="imgfile" type="file" accept="image/*" />
          <div class="hint">ملاحظة: إذا كانت صورة هذا المرياج موجودة مسبقاً لنفس الرسمة ورقم المرياج، سيتم استخدام الصورة القديمة تلقائياً ولن يتم رفع صورة جديدة.</div>
        </div>
        <div class="col">
          <img class="preview" style="max-width:120px;max-height:120px;border-radius:10px;display:none;" />
        </div>
      </div>

      <div class="row" style="justify-content:flex-end;">
        <button class="btn danger remove">حذف هذا المرياج</button>
      </div>
    `;

    group.querySelector(".date").value = todayISO();

    const fileInput = group.querySelector(".imgfile");
    const preview = group.querySelector(".preview");
    fileInput.addEventListener("change", () => {
      const f = fileInput.files && fileInput.files[0];
      if (f) {
        preview.src = URL.createObjectURL(f);
        preview.style.display = "block";
      } else {
        preview.src = "";
        preview.style.display = "none";
      }
    });

    group.querySelector(".remove").addEventListener("click", () => group.remove());
    groupsContainer.appendChild(group);
    setupDigitNormalization();
  }

  addGroupBtn.addEventListener("click", () => makeGroup(0));

  /******************** Data (DB) ********************/
  async function loadPrintedTable() {
    tableMessage.textContent = "جاري تحميل البيانات...";
    const { data, error } = await supabaseClient.from(CFG.TABLE_NAME).select("*");
    if (error) {
      console.error(error);
      tableMessage.textContent = "فشل تحميل البيانات.";
      return;
    }
    printedData = data || [];
    // Best-effort migration: fill image_key / image_path if missing
    await bestEffortBackfillImageFields(printedData);
    updateQualityDatalist();
    renderPrintedTable();
    tableMessage.textContent = "";
  }

  async function bestEffortBackfillImageFields(rows) {
    // If columns exist, update missing values for newer logic.
    // We do not throw if update fails.
    const tasks = [];
    for (const r of rows) {
      if (!r) continue;
      const needsKey = !r.image_key;
      const needsPath = !r.image_path;
      if (!needsKey && !needsPath) continue;

      const design = r.designcode || "";
      const mariage = r.mariagenumber || "";
      const key = buildImageKey(design, mariage);

      let path = null;
      if (r.image_path) path = r.image_path;
      else if (r.imageurl) path = extractStoragePathFromPublicUrl(r.imageurl);
      else path = buildImagePath(design, mariage);

      const payload = {};
      if (needsKey) payload.image_key = key;
      if (needsPath) payload.image_path = path;

      // Do not override imageurl here; keep legacy unless we know deterministic exists.
      tasks.push(
        supabaseClient.from(CFG.TABLE_NAME).update(payload).eq("id", r.id)
          .then(() => { r.image_key = r.image_key || payload.image_key; r.image_path = r.image_path || payload.image_path; })
          .catch(() => {})
      );
    }
    // avoid overloading
    await Promise.all(tasks.slice(0, 50));
  }

  function applyFiltersAndSort() {
    const q = (searchInput.value || "").trim().toLowerCase();
    const st = statusFilter.value;
    const sf = sortField.value;

    let rows = printedData.slice();

    if (q) {
      rows = rows.filter(r => {
        const hay = [
          r.designcode, r.mariagenumber, r.quality, r.printtype, r.groundprep, r.fabric, r.notes
        ].map(x => (x ?? "").toString().toLowerCase()).join(" ");
        return hay.includes(q);
      });
    }
    if (st && st !== "all") {
      rows = rows.filter(r => (r.status || "").trim() === st);
    }

    // Sorting
    const byDate = (a, b) => (a.date || "").localeCompare(b.date || "");
    if (sf === "date_desc") rows.sort((a, b) => byDate(b, a));
    else if (sf === "date_asc") rows.sort((a, b) => byDate(a, b));
    else if (sf === "designcode_asc") rows.sort((a, b) => (a.designcode || "").localeCompare(b.designcode || ""));
    else if (sf === "designcode_desc") rows.sort((a, b) => (b.designcode || "").localeCompare(a.designcode || ""));
    return rows;
  }

  function renderPrintedTable() {
    const rows = applyFiltersAndSort();
    printedTableBody.innerHTML = "";

    let totalQty = 0;
    let count = 0;

    rows.forEach((row, index) => {
      count += 1;
      const qty = Number(row.qtykg || 0);
      if (Number.isFinite(qty)) totalQty += qty;

      const imgUrl = row.imageurl || "";
      const imgHtml = imgUrl
        ? `<img class="printed-table-img" src="${escapeHtml(imgUrl)}" alt="img" />`
        : `<span style="color:#9ca3af;">—</span>`;

      const actionsHtml = `
        <button class="btn small" data-act="edit" data-id="${row.id}">تعديل</button>
        <button class="btn small" data-act="duplicate" data-id="${row.id}">تكرار</button>
        <button class="btn small danger" data-act="delete" data-id="${row.id}">حذف</button>
      `;

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${imgHtml}</td>
        <td>${escapeHtml(row.designcode || "")}</td>
        <td>${escapeHtml(row.screenscount ?? "")}</td>
        <td>${escapeHtml(row.mariagenumber || "")}</td>
        <td>${escapeHtml(row.printtype || "")}</td>
        <td>${escapeHtml(row.groundprep || "")}</td>
        <td>${escapeHtml(row.quality || "")}</td>
        <td>${escapeHtml(row.qtykg ?? "")}</td>
        <td>${escapeHtml(row.date || "")}</td>
        <td>${escapeHtml(row.status || "")}</td>
        <td>${escapeHtml(row.notes || "")}</td>
        <td>${actionsHtml}</td>
      `;
      printedTableBody.appendChild(tr);
    });

    totalsInfo.textContent = `إجمالي عدد المرياجات: ${count} | إجمالي الكمية: ${totalQty || 0} كغ`;
  }

  searchInput.addEventListener("input", () => renderPrintedTable());
  statusFilter.addEventListener("change", () => renderPrintedTable());
  sortField.addEventListener("change", () => renderPrintedTable());

  /************* Autocomplete للخامة *************/
  function updateQualityDatalist() {
    const dl = document.getElementById("qualityList");
    if (!dl) return;
    const set = new Set();
    printedData.forEach(row => { if (row.quality) set.add(row.quality); });
    dl.innerHTML = "";
    Array.from(set).forEach(q => {
      const opt = document.createElement("option");
      opt.value = q;
      dl.appendChild(opt);
    });
  }

  /******************** Create (Save All) ********************/
  saveAllBtn.addEventListener("click", async () => {
    const designcode = arabicToEnglishDigits(designCodeInput.value || "").trim();
    const screenscount = arabicToEnglishDigits(screensCountInput.value || "").trim();

    if (!designcode) { alert("الرجاء إدخال رقم الرسمة."); return; }

    const groups = Array.from(groupsContainer.querySelectorAll(".group"));
    if (!groups.length) { alert("أضف مرياج واحد على الأقل."); return; }

    saveAllBtn.disabled = true;
    saveAllBtn.textContent = "جاري الحفظ...";

    try {
      for (const g of groups) {
        const mariageNumber = arabicToEnglishDigits(g.querySelector(".mariage").value || "").trim();
        if (!mariageNumber) continue;

        const printtype = g.querySelector(".printtype").value || "";
        const groundprep = g.querySelector(".groundprep").value || "";
        const quality = g.querySelector(".quality").value || "";
        const qtykg = sanitizeDecimal(g.querySelector(".qty").value);
        const date = g.querySelector(".date").value || todayISO();
        const status = g.querySelector(".status").value || "لم يتم التشكيل";
        const notes = g.querySelector(".notes").value || "";
        const file = g.querySelector(".imgfile").files?.[0] || null;

        const image_key = buildImageKey(designcode, mariageNumber);
        const image_path = buildImagePath(designcode, mariageNumber);

        let imageurl = null;
        const exists = await storageExists(image_path);

        if (exists) {
          // image already exists => reference it, do NOT overwrite here
          imageurl = await getPublicUrl(image_path);
        } else if (file) {
          // first time upload
          imageurl = await uploadImageToPath(file, image_path, { upsert: false });
        } else {
          imageurl = null;
        }

        const payload = {
          designcode,
          screenscount: screenscount ? Number(onlyDigits(screenscount) || screenscount) : null,
          mariagenumber: arabicToEnglishDigits(mariageNumber),
          printtype,
          groundprep,
          quality,
          qtykg,
          date,
          status,
          notes,
          imageurl,
          image_key,
          image_path
        };

        const { error } = await supabaseClient.from(CFG.TABLE_NAME).insert(payload);
        if (error) throw error;
      }

      groupsContainer.innerHTML = "";
      makeGroup(0);
      await loadPrintedTable();
      alert("تم حفظ الطلبات بنجاح.");
    } catch (e) {
      console.error(e);
      alert("حدث خطأ أثناء الحفظ. راجع الكونسول.");
    } finally {
      saveAllBtn.disabled = false;
      saveAllBtn.textContent = "حفظ كل المرياجات";
    }
  });

  /******************** Table Actions ********************/
  printedTableBody.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const act = btn.getAttribute("data-act");
    const id = Number(btn.getAttribute("data-id"));
    if (!id) return;

    if (act === "edit") openEditModal(id);
    else if (act === "duplicate") openDuplicateModal(id);
    else if (act === "delete") await deleteRow(id);
  });

  async function countOtherRowsByKey(image_key, excludeId) {
    if (!image_key) return 0;
    const { data, error } = await supabaseClient.from(CFG.TABLE_NAME)
      .select("id")
      .eq("image_key", image_key)
      .neq("id", excludeId)
      .limit(2);
    if (error) return 0;
    return (data || []).length;
  }

  async function deleteRow(id) {
    const row = printedData.find(r => r.id === id);
    const ok = confirm("هل تريد حذف هذا المرياج نهائياً؟");
    if (!ok) return;

    // delete record first? safer for refs? We'll check refs before deleting image, excluding this record.
    let otherRefs = 0;
    try { otherRefs = await countOtherRowsByKey(row?.image_key, id); } catch {}

    const { error } = await supabaseClient.from(CFG.TABLE_NAME).delete().eq("id", id);
    if (error) {
      console.error(error);
      alert("لم يتم الحذف.");
      return;
    }

    // Delete image only if no other refs
    if (row) {
      try {
        if (otherRefs === 0) {
          const path = row.image_path || extractStoragePathFromPublicUrl(row.imageurl) || buildImagePath(row.designcode, row.mariagenumber);
          if (path) await deleteStoragePath(path);
        }
      } catch (e) {
        console.warn("خطأ أثناء حذف الصورة من التخزين:", e);
      }
    }

    await loadPrintedTable();
  }

  /******************** Edit Modal ********************/
  function openEditModal(id) {
    const row = printedData.find(r => r.id === id);
    if (!row) return;
    currentEditRow = row;

    document.getElementById("edit_designcode").value = row.designcode || "";
    document.getElementById("edit_screenscount").value = row.screenscount ?? "";
    document.getElementById("edit_mariagenumber").value = row.mariagenumber || "";
    document.getElementById("edit_printtype").value = row.printtype || "";
    document.getElementById("edit_groundprep").value = row.groundprep || "أوفوايت";
    document.getElementById("edit_quality").value = row.quality || "";
    document.getElementById("edit_qtykg").value = row.qtykg ?? "";
    document.getElementById("edit_date").value = row.date || todayISO();
    document.getElementById("edit_status").value = row.status || "لم يتم التشكيل";
    document.getElementById("edit_notes").value = row.notes || "";

    // image preview
    editImagePreview.src = row.imageurl || "";
    editImagePreview.style.display = row.imageurl ? "block" : "none";
    if (editImageFile) editImageFile.value = "";

    editMessage.textContent = "";
    editModalBackdrop.style.display = "flex";
    setupDigitNormalization();
  }

  function closeEditModal() {
    editModalBackdrop.style.display = "none";
    currentEditRow = null;
    if (editImageFile) editImageFile.value = "";
  }

  editModalClose.addEventListener("click", closeEditModal);
  editModalBackdrop.addEventListener("click", (e) => { if (e.target === editModalBackdrop) closeEditModal(); });

  editSaveBtn.addEventListener("click", async () => {
    if (!currentEditRow) return;

    editSaveBtn.disabled = true;
    editSaveBtn.textContent = "جاري الحفظ...";

    try {
      const newDesign = arabicToEnglishDigits(document.getElementById("edit_designcode").value || "").trim();
      const newScreens = arabicToEnglishDigits(document.getElementById("edit_screenscount").value || "").trim();
      const newMariage = arabicToEnglishDigits(document.getElementById("edit_mariagenumber").value || "").trim();

      const payload = {
        designcode: newDesign,
        screenscount: newScreens ? Number(onlyDigits(newScreens) || newScreens) : null,
        mariagenumber: newMariage,
        printtype: document.getElementById("edit_printtype").value || "",
        groundprep: document.getElementById("edit_groundprep").value || "",
        quality: document.getElementById("edit_quality").value || "",
        qtykg: sanitizeDecimal(document.getElementById("edit_qtykg").value),
        date: document.getElementById("edit_date").value || todayISO(),
        status: document.getElementById("edit_status").value || "لم يتم التشكيل",
        notes: document.getElementById("edit_notes").value || ""
      };

      // handle image rename/copy when (design/mariage) changed
      const oldDesign = currentEditRow.designcode || "";
      const oldMariage = currentEditRow.mariagenumber || "";
      const oldKey = currentEditRow.image_key || buildImageKey(oldDesign, oldMariage);
      const newKey = buildImageKey(newDesign, newMariage);

      const hadImage = !!(currentEditRow.imageurl || currentEditRow.image_path);
      if (hadImage) {
        const oldPath = currentEditRow.image_path || extractStoragePathFromPublicUrl(currentEditRow.imageurl) || buildImagePath(oldDesign, oldMariage);
        const newPath = buildImagePath(newDesign, newMariage);

        if (newKey !== oldKey || newPath !== oldPath) {
          const shared = (await countOtherRowsByKey(oldKey, currentEditRow.id)) > 0;
          if (shared) {
            // copy (if needed)
            await copyStoragePath(oldPath, newPath);
          } else {
            // move (rename)
            await moveStoragePath(oldPath, newPath);
          }
          payload.image_key = newKey;
          payload.image_path = newPath;
          payload.imageurl = await getPublicUrl(newPath);
        } else {
          // ensure fields
          payload.image_key = oldKey;
          payload.image_path = oldPath;
        }
      } else {
        // no image: still set key/path for consistency
        payload.image_key = newKey;
        payload.image_path = buildImagePath(newDesign, newMariage);
      }

      const { error } = await supabaseClient.from(CFG.TABLE_NAME).update(payload).eq("id", currentEditRow.id);
      if (error) throw error;

      editMessage.textContent = "تم الحفظ.";
      await loadPrintedTable();
      closeEditModal();
    } catch (e) {
      console.error(e);
      editMessage.textContent = "حدث خطأ أثناء الحفظ.";
    } finally {
      editSaveBtn.disabled = false;
      editSaveBtn.textContent = "حفظ التعديلات";
    }
  });

  // Update image in any time (reference)
  editUpdateImageBtn.addEventListener("click", async () => {
    if (!currentEditRow) return;
    const file = editImageFile?.files?.[0];
    if (!file) { editMessage.textContent = "اختر صورة أولاً."; return; }

    editUpdateImageBtn.disabled = true;
    editUpdateImageBtn.textContent = "جاري تحديث الصورة...";

    try {
      const design = arabicToEnglishDigits(document.getElementById("edit_designcode").value || "").trim();
      const mariage = arabicToEnglishDigits(document.getElementById("edit_mariagenumber").value || "").trim();

      const key = buildImageKey(design, mariage);
      const path = buildImagePath(design, mariage);

      const oldPath = currentEditRow.image_path || extractStoragePathFromPublicUrl(currentEditRow.imageurl);

      // upload (overwrite allowed)
      const url = await uploadImageToPath(file, path, { upsert: true });

      // update current row + also ensure other rows reference same key/path (they already should)
      const { error } = await supabaseClient.from(CFG.TABLE_NAME).update({
        image_key: key,
        image_path: path,
        imageurl: url
      }).eq("id", currentEditRow.id);

      if (error) throw error;

      // if oldPath exists and differs from new path, delete old if no other rows reference it
      if (oldPath && oldPath !== path) {
        const { data } = await supabaseClient.from(CFG.TABLE_NAME).select("id").eq("image_path", oldPath).limit(1);
        const stillRef = (data || []).length > 0;
        if (!stillRef) {
          try { await deleteStoragePath(oldPath); } catch {}
        }
      }

      editImagePreview.src = url;
      editImagePreview.style.display = "block";
      editMessage.textContent = "تم تحديث الصورة.";
      await loadPrintedTable();
    } catch (e) {
      console.error(e);
      editMessage.textContent = "فشل تحديث الصورة.";
    } finally {
      editUpdateImageBtn.disabled = false;
      editUpdateImageBtn.textContent = "تحديث الصورة";
    }
  });

  /******************** Duplicate Modal ********************/
  function openDuplicateModal(id) {
    const row = printedData.find(r => r.id === id);
    if (!row) return;
    currentDupRow = row;

    document.getElementById("dup_designcode").value = row.designcode || "";
    document.getElementById("dup_screenscount").value = row.screenscount ?? "";
    document.getElementById("dup_mariagenumber").value = row.mariagenumber || "";

    document.getElementById("dup_printtype").value = row.printtype || "";
    document.getElementById("dup_groundprep").value = row.groundprep || "أوفوايت";
    document.getElementById("dup_quality").value = row.quality || "";
    document.getElementById("dup_qtykg").value = row.qtykg ?? "";
    document.getElementById("dup_date").value = todayISO();
    document.getElementById("dup_status").value = "لم يتم التشكيل";
    document.getElementById("dup_notes").value = row.notes || "";

    dupImagePreview.src = row.imageurl || "";
    dupImagePreview.style.display = row.imageurl ? "block" : "none";

    dupMessage.textContent = "";
    dupModalBackdrop.style.display = "flex";
    setupDigitNormalization();
  }

  function closeDuplicateModal() {
    dupModalBackdrop.style.display = "none";
    currentDupRow = null;
  }

  dupModalClose.addEventListener("click", closeDuplicateModal);
  dupModalBackdrop.addEventListener("click", (e) => { if (e.target === dupModalBackdrop) closeDuplicateModal(); });

  dupSaveBtn.addEventListener("click", async () => {
    if (!currentDupRow) return;

    dupSaveBtn.disabled = true;
    dupSaveBtn.textContent = "جاري الحفظ...";

    try {
      const design = arabicToEnglishDigits(document.getElementById("dup_designcode").value || "").trim();
      const screens = arabicToEnglishDigits(document.getElementById("dup_screenscount").value || "").trim();
      const mariage = arabicToEnglishDigits(document.getElementById("dup_mariagenumber").value || "").trim();

      const key = buildImageKey(design, mariage);
      const path = buildImagePath(design, mariage);

      // ensure image exists: if current row had legacy path, we still point to deterministic. If deterministic doesn't exist but legacy does, keep legacy for now.
      let imageurl = null;
      let image_path = path;

      const detExists = await storageExists(path);
      if (detExists) {
        imageurl = await getPublicUrl(path);
      } else if (currentDupRow.image_path) {
        image_path = currentDupRow.image_path;
        imageurl = currentDupRow.imageurl || await getPublicUrl(image_path);
      } else if (currentDupRow.imageurl) {
        image_path = extractStoragePathFromPublicUrl(currentDupRow.imageurl) || path;
        imageurl = currentDupRow.imageurl;
      }

      const payload = {
        designcode: design,
        screenscount: screens ? Number(onlyDigits(screens) || screens) : null,
        mariagenumber: mariage,
        printtype: document.getElementById("dup_printtype").value || "",
        groundprep: document.getElementById("dup_groundprep").value || "",
        quality: document.getElementById("dup_quality").value || "",
        qtykg: sanitizeDecimal(document.getElementById("dup_qtykg").value),
        date: document.getElementById("dup_date").value || todayISO(),
        status: document.getElementById("dup_status").value || "لم يتم التشكيل",
        notes: document.getElementById("dup_notes").value || "",
        image_key: key,
        image_path,
        imageurl
      };

      const { error } = await supabaseClient.from(CFG.TABLE_NAME).insert(payload);
      if (error) throw error;

      await loadPrintedTable();
      closeDuplicateModal();
    } catch (e) {
      console.error(e);
      dupMessage.textContent = "فشل حفظ التكرار.";
    } finally {
      dupSaveBtn.disabled = false;
      dupSaveBtn.textContent = "حفظ كطلب جديد";
    }
  });

  /******************** Image zoom ********************/
  printedTableBody.addEventListener("click", (e) => {
    const img = e.target.closest(".printed-table-img");
    if (img) {
      imageModalImg.src = img.src;
      imageModal.style.display = "flex";
    }
  });
  imageModal.addEventListener("click", () => { imageModal.style.display = "none"; });

  /******************** Init ********************/
  // Ensure at least one group exists
  if (groupsContainer.children.length === 0) makeGroup(0);
  setupDigitNormalization();
  loadPrintedTable();

})();
